﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FILEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItemEntranceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItemSalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ItemReceivedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BranchIssuerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapitalizedIssuerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpenseIssuerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesIssuerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VIEWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewStoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewCustomerDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewSupplierDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewQuantityOnStoreDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewStockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BranchDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewRecordsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ABOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutSoftwareToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutDeveloperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ItemSalesFormControl1 = New IS_NTC_ControlLibrary.ItemSalesFormControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ItemEntranceFormControl1 = New IS_NTC_ControlLibrary.ItemEntranceFormControl()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.ItemReceivedFormControl1 = New IS_NTC_ControlLibrary.ItemReceivedFormControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Branch_IssuerFormControl1 = New IS_NTC_ControlLibrary.Branch_IssuerFormControl()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Capitalized_IssuerFormControl1 = New IS_NTC_ControlLibrary.Capitalized_IssuerFormControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Expense_IssuerFormControl1 = New IS_NTC_ControlLibrary.Expense_IssuerFormControl()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Sales_IssuerFormControl1 = New IS_NTC_ControlLibrary.Sales_IssuerFormControl()
        Me.MenuStrip1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FILEToolStripMenuItem, Me.ToolStripMenuItem1, Me.VIEWToolStripMenuItem, Me.ABOUTToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1264, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FILEToolStripMenuItem
        '
        Me.FILEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SettingsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FILEToolStripMenuItem.Name = "FILEToolStripMenuItem"
        Me.FILEToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.FILEToolStripMenuItem.Text = "FILE"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.Image = CType(resources.GetObject("SettingsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Image = CType(resources.GetObject("ExitToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ToolStripMenuItem11})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(52, 20)
        Me.ToolStripMenuItem1.Text = "FORM"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ItemEntranceToolStripMenuItem, Me.ItemSalesToolStripMenuItem})
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(131, 22)
        Me.ToolStripMenuItem2.Text = "View Store"
        '
        'ItemEntranceToolStripMenuItem
        '
        Me.ItemEntranceToolStripMenuItem.Checked = True
        Me.ItemEntranceToolStripMenuItem.CheckOnClick = True
        Me.ItemEntranceToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ItemEntranceToolStripMenuItem.Name = "ItemEntranceToolStripMenuItem"
        Me.ItemEntranceToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.ItemEntranceToolStripMenuItem.Text = "Item Entrance"
        '
        'ItemSalesToolStripMenuItem
        '
        Me.ItemSalesToolStripMenuItem.CheckOnClick = True
        Me.ItemSalesToolStripMenuItem.Name = "ItemSalesToolStripMenuItem"
        Me.ItemSalesToolStripMenuItem.Size = New System.Drawing.Size(147, 22)
        Me.ItemSalesToolStripMenuItem.Text = "Item Sales"
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ItemReceivedToolStripMenuItem, Me.BranchIssuerToolStripMenuItem, Me.CapitalizedIssuerToolStripMenuItem, Me.ExpenseIssuerToolStripMenuItem, Me.SalesIssuerToolStripMenuItem})
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(131, 22)
        Me.ToolStripMenuItem11.Text = "View Stock"
        '
        'ItemReceivedToolStripMenuItem
        '
        Me.ItemReceivedToolStripMenuItem.CheckOnClick = True
        Me.ItemReceivedToolStripMenuItem.Name = "ItemReceivedToolStripMenuItem"
        Me.ItemReceivedToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ItemReceivedToolStripMenuItem.Text = "Item Received"
        '
        'BranchIssuerToolStripMenuItem
        '
        Me.BranchIssuerToolStripMenuItem.CheckOnClick = True
        Me.BranchIssuerToolStripMenuItem.Name = "BranchIssuerToolStripMenuItem"
        Me.BranchIssuerToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.BranchIssuerToolStripMenuItem.Text = "Branch-Issuer"
        '
        'CapitalizedIssuerToolStripMenuItem
        '
        Me.CapitalizedIssuerToolStripMenuItem.CheckOnClick = True
        Me.CapitalizedIssuerToolStripMenuItem.Name = "CapitalizedIssuerToolStripMenuItem"
        Me.CapitalizedIssuerToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.CapitalizedIssuerToolStripMenuItem.Text = "Capitalized-Issuer"
        '
        'ExpenseIssuerToolStripMenuItem
        '
        Me.ExpenseIssuerToolStripMenuItem.CheckOnClick = True
        Me.ExpenseIssuerToolStripMenuItem.Name = "ExpenseIssuerToolStripMenuItem"
        Me.ExpenseIssuerToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ExpenseIssuerToolStripMenuItem.Text = "Expense-Issuer"
        '
        'SalesIssuerToolStripMenuItem
        '
        Me.SalesIssuerToolStripMenuItem.CheckOnClick = True
        Me.SalesIssuerToolStripMenuItem.Name = "SalesIssuerToolStripMenuItem"
        Me.SalesIssuerToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.SalesIssuerToolStripMenuItem.Text = "Sales-Issuer"
        '
        'VIEWToolStripMenuItem
        '
        Me.VIEWToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewStoreToolStripMenuItem, Me.ViewStockToolStripMenuItem})
        Me.VIEWToolStripMenuItem.Name = "VIEWToolStripMenuItem"
        Me.VIEWToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.VIEWToolStripMenuItem.Text = "RECORD"
        '
        'ViewStoreToolStripMenuItem
        '
        Me.ViewStoreToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewCustomerDetailsToolStripMenuItem, Me.ViewSupplierDetailsToolStripMenuItem, Me.ViewQuantityOnStoreDetailsToolStripMenuItem})
        Me.ViewStoreToolStripMenuItem.Name = "ViewStoreToolStripMenuItem"
        Me.ViewStoreToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.ViewStoreToolStripMenuItem.Text = "View Store"
        '
        'ViewCustomerDetailsToolStripMenuItem
        '
        Me.ViewCustomerDetailsToolStripMenuItem.Name = "ViewCustomerDetailsToolStripMenuItem"
        Me.ViewCustomerDetailsToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.ViewCustomerDetailsToolStripMenuItem.Text = "Customer Details"
        '
        'ViewSupplierDetailsToolStripMenuItem
        '
        Me.ViewSupplierDetailsToolStripMenuItem.Name = "ViewSupplierDetailsToolStripMenuItem"
        Me.ViewSupplierDetailsToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.ViewSupplierDetailsToolStripMenuItem.Text = "Supplier Details"
        '
        'ViewQuantityOnStoreDetailsToolStripMenuItem
        '
        Me.ViewQuantityOnStoreDetailsToolStripMenuItem.Name = "ViewQuantityOnStoreDetailsToolStripMenuItem"
        Me.ViewQuantityOnStoreDetailsToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.ViewQuantityOnStoreDetailsToolStripMenuItem.Text = "Quantity on Store Details"
        '
        'ViewStockToolStripMenuItem
        '
        Me.ViewStockToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BranchDetailsToolStripMenuItem, Me.CustomerDetailsToolStripMenuItem, Me.ViewRecordsToolStripMenuItem1})
        Me.ViewStockToolStripMenuItem.Name = "ViewStockToolStripMenuItem"
        Me.ViewStockToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.ViewStockToolStripMenuItem.Text = "View Stock"
        '
        'BranchDetailsToolStripMenuItem
        '
        Me.BranchDetailsToolStripMenuItem.Name = "BranchDetailsToolStripMenuItem"
        Me.BranchDetailsToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.BranchDetailsToolStripMenuItem.Text = "Branch Details"
        '
        'CustomerDetailsToolStripMenuItem
        '
        Me.CustomerDetailsToolStripMenuItem.Name = "CustomerDetailsToolStripMenuItem"
        Me.CustomerDetailsToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.CustomerDetailsToolStripMenuItem.Text = "Customer Details"
        '
        'ViewRecordsToolStripMenuItem1
        '
        Me.ViewRecordsToolStripMenuItem1.Name = "ViewRecordsToolStripMenuItem1"
        Me.ViewRecordsToolStripMenuItem1.Size = New System.Drawing.Size(207, 22)
        Me.ViewRecordsToolStripMenuItem1.Text = "Quantity on Stock Details"
        '
        'ABOUTToolStripMenuItem
        '
        Me.ABOUTToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutSoftwareToolStripMenuItem, Me.AboutDeveloperToolStripMenuItem})
        Me.ABOUTToolStripMenuItem.Name = "ABOUTToolStripMenuItem"
        Me.ABOUTToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.ABOUTToolStripMenuItem.Text = "ABOUT"
        '
        'AboutSoftwareToolStripMenuItem
        '
        Me.AboutSoftwareToolStripMenuItem.Image = CType(resources.GetObject("AboutSoftwareToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutSoftwareToolStripMenuItem.Name = "AboutSoftwareToolStripMenuItem"
        Me.AboutSoftwareToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.AboutSoftwareToolStripMenuItem.Text = "About Software"
        '
        'AboutDeveloperToolStripMenuItem
        '
        Me.AboutDeveloperToolStripMenuItem.Image = CType(resources.GetObject("AboutDeveloperToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AboutDeveloperToolStripMenuItem.Name = "AboutDeveloperToolStripMenuItem"
        Me.AboutDeveloperToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.AboutDeveloperToolStripMenuItem.Text = "About Developer"
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage2.Controls.Add(Me.ItemSalesFormControl1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1256, 628)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Item Sales"
        '
        'ItemSalesFormControl1
        '
        Me.ItemSalesFormControl1.AutoScroll = True
        Me.ItemSalesFormControl1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ItemSalesFormControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ItemSalesFormControl1.Location = New System.Drawing.Point(3, 3)
        Me.ItemSalesFormControl1.Name = "ItemSalesFormControl1"
        Me.ItemSalesFormControl1.Size = New System.Drawing.Size(1250, 622)
        Me.ItemSalesFormControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage1.Controls.Add(Me.ItemEntranceFormControl1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1256, 628)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Item Entrance"
        '
        'ItemEntranceFormControl1
        '
        Me.ItemEntranceFormControl1.AutoScroll = True
        Me.ItemEntranceFormControl1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ItemEntranceFormControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ItemEntranceFormControl1.Location = New System.Drawing.Point(3, 3)
        Me.ItemEntranceFormControl1.Name = "ItemEntranceFormControl1"
        Me.ItemEntranceFormControl1.Size = New System.Drawing.Size(1250, 622)
        Me.ItemEntranceFormControl1.TabIndex = 0
        '
        'TabControl1
        '
        Me.TabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 24)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1264, 657)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight
        Me.TabControl1.TabIndex = 1
        Me.TabControl1.TabStop = False
        '
        'TabPage3
        '
        Me.TabPage3.AutoScroll = True
        Me.TabPage3.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage3.Controls.Add(Me.ItemReceivedFormControl1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1256, 628)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Item Received"
        '
        'ItemReceivedFormControl1
        '
        Me.ItemReceivedFormControl1.AutoScroll = True
        Me.ItemReceivedFormControl1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ItemReceivedFormControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ItemReceivedFormControl1.Location = New System.Drawing.Point(0, 0)
        Me.ItemReceivedFormControl1.Name = "ItemReceivedFormControl1"
        Me.ItemReceivedFormControl1.Size = New System.Drawing.Size(1256, 628)
        Me.ItemReceivedFormControl1.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.AutoScroll = True
        Me.TabPage4.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage4.Controls.Add(Me.Branch_IssuerFormControl1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1256, 628)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Branch-Issuer"
        '
        'Branch_IssuerFormControl1
        '
        Me.Branch_IssuerFormControl1.AutoScroll = True
        Me.Branch_IssuerFormControl1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Branch_IssuerFormControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Branch_IssuerFormControl1.Location = New System.Drawing.Point(0, 0)
        Me.Branch_IssuerFormControl1.Name = "Branch_IssuerFormControl1"
        Me.Branch_IssuerFormControl1.Size = New System.Drawing.Size(1256, 628)
        Me.Branch_IssuerFormControl1.TabIndex = 0
        '
        'TabPage5
        '
        Me.TabPage5.AutoScroll = True
        Me.TabPage5.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage5.Controls.Add(Me.Capitalized_IssuerFormControl1)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1256, 628)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Capitalized-Issuer"
        '
        'Capitalized_IssuerFormControl1
        '
        Me.Capitalized_IssuerFormControl1.AutoScroll = True
        Me.Capitalized_IssuerFormControl1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Capitalized_IssuerFormControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Capitalized_IssuerFormControl1.Location = New System.Drawing.Point(0, 0)
        Me.Capitalized_IssuerFormControl1.Name = "Capitalized_IssuerFormControl1"
        Me.Capitalized_IssuerFormControl1.Size = New System.Drawing.Size(1256, 628)
        Me.Capitalized_IssuerFormControl1.TabIndex = 0
        '
        'TabPage6
        '
        Me.TabPage6.AutoScroll = True
        Me.TabPage6.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage6.Controls.Add(Me.Expense_IssuerFormControl1)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(1256, 628)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Expense-Issuer"
        '
        'Expense_IssuerFormControl1
        '
        Me.Expense_IssuerFormControl1.AutoScroll = True
        Me.Expense_IssuerFormControl1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Expense_IssuerFormControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Expense_IssuerFormControl1.Location = New System.Drawing.Point(0, 0)
        Me.Expense_IssuerFormControl1.Name = "Expense_IssuerFormControl1"
        Me.Expense_IssuerFormControl1.Size = New System.Drawing.Size(1256, 628)
        Me.Expense_IssuerFormControl1.TabIndex = 0
        '
        'TabPage7
        '
        Me.TabPage7.AutoScroll = True
        Me.TabPage7.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TabPage7.Controls.Add(Me.Sales_IssuerFormControl1)
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(1256, 628)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Sales-Issuer"
        '
        'Sales_IssuerFormControl1
        '
        Me.Sales_IssuerFormControl1.AutoScroll = True
        Me.Sales_IssuerFormControl1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Sales_IssuerFormControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Sales_IssuerFormControl1.Location = New System.Drawing.Point(0, 0)
        Me.Sales_IssuerFormControl1.Name = "Sales_IssuerFormControl1"
        Me.Sales_IssuerFormControl1.Size = New System.Drawing.Size(1256, 628)
        Me.Sales_IssuerFormControl1.TabIndex = 0
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1264, 681)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(1280, 720)
        Me.MinimizeBox = False
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inventory System-Nepal Telecom"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FILEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VIEWToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ABOUTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutSoftwareToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutDeveloperToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewStoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewQuantityOnStoreDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewStockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewRecordsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItemEntranceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItemSalesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItemReceivedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BranchIssuerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CapitalizedIssuerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExpenseIssuerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesIssuerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewSupplierDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents ItemEntranceFormControl1 As IS_NTC_ControlLibrary.ItemEntranceFormControl
    Friend WithEvents ItemSalesFormControl1 As IS_NTC_ControlLibrary.ItemSalesFormControl
    Friend WithEvents ViewCustomerDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BranchDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents ItemReceivedFormControl1 As IS_NTC_ControlLibrary.ItemReceivedFormControl
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Branch_IssuerFormControl1 As IS_NTC_ControlLibrary.Branch_IssuerFormControl
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Capitalized_IssuerFormControl1 As IS_NTC_ControlLibrary.Capitalized_IssuerFormControl
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Expense_IssuerFormControl1 As IS_NTC_ControlLibrary.Expense_IssuerFormControl
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents Sales_IssuerFormControl1 As IS_NTC_ControlLibrary.Sales_IssuerFormControl

End Class
