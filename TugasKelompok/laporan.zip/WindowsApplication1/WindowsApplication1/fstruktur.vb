﻿Public Class fstruktur

End Class