﻿Public Class fmaster

    Private Sub MASTERToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MASTERToolStripMenuItem.Click

    End Sub

    Private Sub KELUARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KELUARToolStripMenuItem.Click

    End Sub

    Private Sub fmaster_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LAPORANANGGOTAToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LAPORANANGGOTAToolStripMenuItem.Click
        Form1.Show()
    End Sub

    Private Sub LAPPENGAMBILANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LAPPENGAMBILANToolStripMenuItem.Click
        lapPengambilan.Show()

    End Sub
End Class
