﻿Public Class lapPengambilan

End Class