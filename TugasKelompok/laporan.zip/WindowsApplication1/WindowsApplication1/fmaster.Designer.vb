﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fmaster
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MASTERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ANGGOTAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PETUGASToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.STRUKTURORGANISASIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TRANSAKSIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SIMPANANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PINJAMANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PENGAMBILANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SHUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TOTALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAPORANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAPSIMPANANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAPPINJAMANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAPPENGAMBILANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAPSHUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAPTOTALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAPORANANGGOTAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ABOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PROGRAMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.KELOMPOKToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.KELUARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LOGINToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LOGOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MASTERToolStripMenuItem
        '
        Me.MASTERToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ANGGOTAToolStripMenuItem, Me.PETUGASToolStripMenuItem, Me.STRUKTURORGANISASIToolStripMenuItem})
        Me.MASTERToolStripMenuItem.Name = "MASTERToolStripMenuItem"
        Me.MASTERToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.MASTERToolStripMenuItem.Text = "MASTER"
        '
        'ANGGOTAToolStripMenuItem
        '
        Me.ANGGOTAToolStripMenuItem.Name = "ANGGOTAToolStripMenuItem"
        Me.ANGGOTAToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.ANGGOTAToolStripMenuItem.Text = "ANGGOTA"
        '
        'PETUGASToolStripMenuItem
        '
        Me.PETUGASToolStripMenuItem.Name = "PETUGASToolStripMenuItem"
        Me.PETUGASToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.PETUGASToolStripMenuItem.Text = "PETUGAS"
        '
        'STRUKTURORGANISASIToolStripMenuItem
        '
        Me.STRUKTURORGANISASIToolStripMenuItem.Name = "STRUKTURORGANISASIToolStripMenuItem"
        Me.STRUKTURORGANISASIToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.STRUKTURORGANISASIToolStripMenuItem.Text = "STRUKTUR ORGANISASI"
        '
        'TRANSAKSIToolStripMenuItem
        '
        Me.TRANSAKSIToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SIMPANANToolStripMenuItem, Me.PINJAMANToolStripMenuItem, Me.PENGAMBILANToolStripMenuItem, Me.SHUToolStripMenuItem, Me.TOTALToolStripMenuItem})
        Me.TRANSAKSIToolStripMenuItem.Name = "TRANSAKSIToolStripMenuItem"
        Me.TRANSAKSIToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.TRANSAKSIToolStripMenuItem.Text = "TRANSAKSI"
        '
        'SIMPANANToolStripMenuItem
        '
        Me.SIMPANANToolStripMenuItem.Name = "SIMPANANToolStripMenuItem"
        Me.SIMPANANToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.SIMPANANToolStripMenuItem.Text = "SIMPANAN"
        '
        'PINJAMANToolStripMenuItem
        '
        Me.PINJAMANToolStripMenuItem.Name = "PINJAMANToolStripMenuItem"
        Me.PINJAMANToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.PINJAMANToolStripMenuItem.Text = "PINJAMAN"
        '
        'PENGAMBILANToolStripMenuItem
        '
        Me.PENGAMBILANToolStripMenuItem.Name = "PENGAMBILANToolStripMenuItem"
        Me.PENGAMBILANToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.PENGAMBILANToolStripMenuItem.Text = "PENGAMBILAN"
        '
        'SHUToolStripMenuItem
        '
        Me.SHUToolStripMenuItem.Name = "SHUToolStripMenuItem"
        Me.SHUToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.SHUToolStripMenuItem.Text = "SHU"
        '
        'TOTALToolStripMenuItem
        '
        Me.TOTALToolStripMenuItem.Name = "TOTALToolStripMenuItem"
        Me.TOTALToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.TOTALToolStripMenuItem.Text = "TOTAL"
        '
        'LAPORANToolStripMenuItem
        '
        Me.LAPORANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LAPSIMPANANToolStripMenuItem, Me.LAPPINJAMANToolStripMenuItem, Me.LAPPENGAMBILANToolStripMenuItem, Me.LAPSHUToolStripMenuItem, Me.LAPTOTALToolStripMenuItem, Me.LAPORANANGGOTAToolStripMenuItem})
        Me.LAPORANToolStripMenuItem.Name = "LAPORANToolStripMenuItem"
        Me.LAPORANToolStripMenuItem.Size = New System.Drawing.Size(73, 20)
        Me.LAPORANToolStripMenuItem.Text = "LAPORAN"
        '
        'LAPSIMPANANToolStripMenuItem
        '
        Me.LAPSIMPANANToolStripMenuItem.Name = "LAPSIMPANANToolStripMenuItem"
        Me.LAPSIMPANANToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.LAPSIMPANANToolStripMenuItem.Text = "LAPORAN SIMPANAN"
        '
        'LAPPINJAMANToolStripMenuItem
        '
        Me.LAPPINJAMANToolStripMenuItem.Name = "LAPPINJAMANToolStripMenuItem"
        Me.LAPPINJAMANToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.LAPPINJAMANToolStripMenuItem.Text = "LAPORAN PINJAMAN"
        '
        'LAPPENGAMBILANToolStripMenuItem
        '
        Me.LAPPENGAMBILANToolStripMenuItem.Name = "LAPPENGAMBILANToolStripMenuItem"
        Me.LAPPENGAMBILANToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.LAPPENGAMBILANToolStripMenuItem.Text = "LAPORAN PENGAMBILAN"
        '
        'LAPSHUToolStripMenuItem
        '
        Me.LAPSHUToolStripMenuItem.Name = "LAPSHUToolStripMenuItem"
        Me.LAPSHUToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.LAPSHUToolStripMenuItem.Text = "LAPORAN SHU"
        '
        'LAPTOTALToolStripMenuItem
        '
        Me.LAPTOTALToolStripMenuItem.Name = "LAPTOTALToolStripMenuItem"
        Me.LAPTOTALToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.LAPTOTALToolStripMenuItem.Text = "LAPORAN TOTAL"
        '
        'LAPORANANGGOTAToolStripMenuItem
        '
        Me.LAPORANANGGOTAToolStripMenuItem.Name = "LAPORANANGGOTAToolStripMenuItem"
        Me.LAPORANANGGOTAToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.LAPORANANGGOTAToolStripMenuItem.Text = "LAPORAN ANGGOTA"
        '
        'ABOUTToolStripMenuItem
        '
        Me.ABOUTToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PROGRAMToolStripMenuItem, Me.KELOMPOKToolStripMenuItem})
        Me.ABOUTToolStripMenuItem.Name = "ABOUTToolStripMenuItem"
        Me.ABOUTToolStripMenuItem.Size = New System.Drawing.Size(58, 20)
        Me.ABOUTToolStripMenuItem.Text = "ABOUT"
        '
        'PROGRAMToolStripMenuItem
        '
        Me.PROGRAMToolStripMenuItem.Name = "PROGRAMToolStripMenuItem"
        Me.PROGRAMToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.PROGRAMToolStripMenuItem.Text = "PROGRAM"
        '
        'KELOMPOKToolStripMenuItem
        '
        Me.KELOMPOKToolStripMenuItem.Name = "KELOMPOKToolStripMenuItem"
        Me.KELOMPOKToolStripMenuItem.Size = New System.Drawing.Size(136, 22)
        Me.KELOMPOKToolStripMenuItem.Text = "KELOMPOK"
        '
        'KELUARToolStripMenuItem
        '
        Me.KELUARToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LOGINToolStripMenuItem, Me.LOGOUTToolStripMenuItem, Me.EXITToolStripMenuItem})
        Me.KELUARToolStripMenuItem.Name = "KELUARToolStripMenuItem"
        Me.KELUARToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.KELUARToolStripMenuItem.Text = "WINDOW"
        '
        'LOGINToolStripMenuItem
        '
        Me.LOGINToolStripMenuItem.Name = "LOGINToolStripMenuItem"
        Me.LOGINToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.LOGINToolStripMenuItem.Text = "LOGIN"
        '
        'LOGOUTToolStripMenuItem
        '
        Me.LOGOUTToolStripMenuItem.Name = "LOGOUTToolStripMenuItem"
        Me.LOGOUTToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.LOGOUTToolStripMenuItem.Text = "LOGOUT"
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.EXITToolStripMenuItem.Text = "EXIT"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MASTERToolStripMenuItem, Me.TRANSAKSIToolStripMenuItem, Me.LAPORANToolStripMenuItem, Me.ABOUTToolStripMenuItem, Me.KELUARToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(890, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'fmaster
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(890, 311)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "fmaster"
        Me.Text = "Data Master"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MASTERToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ANGGOTAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PETUGASToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STRUKTURORGANISASIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TRANSAKSIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SIMPANANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PINJAMANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PENGAMBILANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHUToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TOTALToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPORANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPSIMPANANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPPINJAMANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPPENGAMBILANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPSHUToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPTOTALToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ABOUTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PROGRAMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KELOMPOKToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KELUARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LOGINToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LOGOUTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents LAPORANANGGOTAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
